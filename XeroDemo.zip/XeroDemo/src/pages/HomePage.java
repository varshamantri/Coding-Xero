package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage{
	public WebDriver driver;
	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(this.driver, this);
	}
	@FindBy(id="Accounts")
	private WebElement tabAccounts;
	@FindBy(css="ul.xn-h-menu-list.a-fade-in>li:nth-child(1)") 
	private WebElement subMenuBankAccounts;
	
	/**
	 * This method is used to click on the Accounts Tab
	 */
	public void clickAccounts() {
		tabAccounts.click();
	}
	
	/**
	 * This method is used to navigate to the Bank Accounts Page
	 * @return BankAccountsPage
	 */
	public BankAccountsPage selectMenuBankAccounts() {
		subMenuBankAccounts.click();
		return new BankAccountsPage(driver);
	}
	
}
