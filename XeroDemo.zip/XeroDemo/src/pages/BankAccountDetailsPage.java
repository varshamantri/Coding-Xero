package pages;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BankAccountDetailsPage {
	public WebDriver driver;
	WebDriverWait wait;
	public BankAccountDetailsPage(WebDriver driver) {
		this.driver = driver;
		this.wait = new WebDriverWait(driver, 5);
		PageFactory.initElements(this.driver, this);
	}
	@FindBy(css="input[id^='accountname']")
	private WebElement txtAccountName;
	@FindBy(css="input[id^='accounttype']")
	private WebElement drpAccountType;
	@FindBy(css="span[id^='common-button-submit']")
	private WebElement btnContinue;
	@FindBy(css="div[id^='accountnumber']>div>div>input[id^='accountnumber']")
	private List<WebElement> list;
	
	/**
	 * This method is used to enter the bank account details of the user
	 * @param dataMap
	 * @param timeStamp
	 */
	public void enterBankAccountDetails(Map<String, String> dataMap, String timeStamp) {
		String accountName = timeStamp + dataMap.get("accountName");
		String accountNumber = dataMap.get("accountNumber");
		wait.until(ExpectedConditions.visibilityOf(txtAccountName));
		txtAccountName.clear();
		txtAccountName.sendKeys(accountName);
		drpAccountType.click();
		drpAccountType.sendKeys(Keys.TAB);
		WebElement txtAccountNumber = list.get(3);
		txtAccountNumber.sendKeys(accountNumber);
	}
	
	/**
	 * This method is used to submit the bank account details of the user
	 * @param bankAccountsPage
	 * @return BankAccountsPage
	 */
	public BankAccountsPage clickOnContinue(BankAccountsPage bankAccountsPage) {
		btnContinue.click();
		return bankAccountsPage;
	}
}
